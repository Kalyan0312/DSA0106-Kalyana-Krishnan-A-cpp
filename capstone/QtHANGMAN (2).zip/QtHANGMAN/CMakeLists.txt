cmake_minimum_required(VERSION 3.16)
project(HangmanQt VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt6 REQUIRED COMPONENTS Widgets)

add_executable(Hangman
    src/main.cpp
    src/HangmanGame.h
    src/HangmanGame.cpp
    src/HangmanWidget.h
    src/HangmanWidget.cpp
    src/MainWindow.h
    src/MainWindow.cpp
)

target_link_libraries(Hangman PRIVATE Qt6::Widgets)
