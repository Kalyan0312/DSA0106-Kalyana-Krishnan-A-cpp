#pragma once

#include <QWidget>

class HangmanWidget : public QWidget
{
    Q_OBJECT

public:
    explicit HangmanWidget(QWidget *parent = nullptr);
    void setWrongCount(int count);

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    int m_wrongCount = 0;
};
