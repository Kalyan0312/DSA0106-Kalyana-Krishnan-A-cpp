#include "MainWindow.h"
#include "HangmanWidget.h"

#include <QStackedWidget>
#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QFrame>
#include <QMessageBox>
#include <QFont>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle("Hangman");
    resize(900, 650);
    setMinimumSize(720, 560);

    m_pages = new QStackedWidget(this);
    setCentralWidget(m_pages);

    buildMenuPage();
    buildGamePage();
    buildResultPage();
    applyStyle();

    m_pages->setCurrentWidget(m_menuPage);
}

QPushButton *MainWindow::makeButton(const QString &text, const QString &objectName)
{
    auto *button = new QPushButton(text);
    button->setCursor(Qt::PointingHandCursor);
    button->setMinimumHeight(44);
    if (!objectName.isEmpty())
        button->setObjectName(objectName);
    return button;
}

void MainWindow::buildMenuPage()
{
    m_menuPage = new QWidget;
    auto *layout = new QVBoxLayout(m_menuPage);
    layout->setContentsMargins(70, 55, 70, 55);
    layout->addStretch();

    auto *title = new QLabel("HANGMAN");
    title->setObjectName("mainTitle");
    title->setAlignment(Qt::AlignCenter);

    auto *subtitle = new QLabel("A simple word-guessing game");
    subtitle->setObjectName("subtitle");
    subtitle->setAlignment(Qt::AlignCenter);

    auto *lengthTitle = new QLabel("Choose word length");
    lengthTitle->setAlignment(Qt::AlignCenter);
    m_lengthBox = new QComboBox;
    for (int length = 3; length <= 10; ++length)
        m_lengthBox->addItem(QString("%1 letters").arg(length), length);

    auto *play = makeButton("Play game", "primaryButton");
    auto *howTo = makeButton("How to play");
    auto *quit = makeButton("Quit");

    layout->addWidget(title);
    layout->addWidget(subtitle);
    layout->addSpacing(38);
    layout->addWidget(lengthTitle);
    layout->addWidget(m_lengthBox, 0, Qt::AlignHCenter);
    m_lengthBox->setFixedWidth(220);
    layout->addSpacing(16);
    layout->addWidget(play);
    layout->addWidget(howTo);
    layout->addWidget(quit);
    layout->addStretch();

    connect(play, &QPushButton::clicked, this, &MainWindow::startGame);
    connect(howTo, &QPushButton::clicked, this, [this] {
        QMessageBox::information(this, "How to play",
            "Guess the hidden word one letter at a time.\n"
            "Each incorrect guess adds one part to the hangman.\n"
            "You have six incorrect guesses. Guess the word before they run out!");
    });
    connect(quit, &QPushButton::clicked, this, &QWidget::close);

    m_pages->addWidget(m_menuPage);
}

void MainWindow::buildGamePage()
{
    m_gamePage = new QWidget;
    auto *root = new QVBoxLayout(m_gamePage);
    root->setContentsMargins(34, 24, 34, 24);
    root->setSpacing(14);

    auto *top = new QHBoxLayout;
    auto *back = makeButton("← Main menu");
    back->setMaximumWidth(150);
    auto *heading = new QLabel("HANGMAN");
    heading->setObjectName("sectionTitle");
    heading->setAlignment(Qt::AlignCenter);
    top->addWidget(back);
    top->addStretch();
    top->addWidget(heading);
    top->addStretch();
    auto *spacer = new QWidget;
    spacer->setFixedWidth(150);
    top->addWidget(spacer);
    root->addLayout(top);

    auto *content = new QHBoxLayout;
    m_figure = new HangmanWidget;

    auto *rightPanel = new QVBoxLayout;
    m_attemptsLabel = new QLabel;
    m_attemptsLabel->setObjectName("attempts");
    m_wordLabel = new QLabel;
    m_wordLabel->setObjectName("word");
    m_wordLabel->setAlignment(Qt::AlignCenter);
    m_guessedLabel = new QLabel;
    m_guessedLabel->setAlignment(Qt::AlignCenter);
    m_feedbackLabel = new QLabel("Choose a letter");
    m_feedbackLabel->setObjectName("feedback");
    m_feedbackLabel->setAlignment(Qt::AlignCenter);

    rightPanel->addWidget(m_attemptsLabel);
    rightPanel->addSpacing(10);
    rightPanel->addWidget(m_wordLabel);
    rightPanel->addWidget(m_guessedLabel);
    rightPanel->addWidget(m_feedbackLabel);
    rightPanel->addStretch();

    auto *keyboard = new QGridLayout;
    keyboard->setSpacing(7);
    const QString letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (int i = 0; i < letters.size(); ++i) {
        const QString letter(letters.at(i));
        auto *key = makeButton(letter, "letterButton");
        key->setFixedSize(48, 42);
        keyboard->addWidget(key, i / 9, i % 9);
        connect(key, &QPushButton::clicked, this, [this, letter, key] {
            handleLetter(letter);
            if (m_game.isFinished())
                key->setEnabled(false);
        });
    }
    rightPanel->addLayout(keyboard);

    content->addWidget(m_figure, 1);
    auto *rightWidget = new QWidget;
    rightWidget->setLayout(rightPanel);
    content->addWidget(rightWidget, 2);
    root->addLayout(content, 1);

    auto *bottom = new QHBoxLayout;
    auto *newGame = makeButton("New game");
    auto *menu = makeButton("Main menu");
    bottom->addStretch();
    bottom->addWidget(newGame);
    bottom->addWidget(menu);
    root->addLayout(bottom);

    connect(back, &QPushButton::clicked, this, [this] {
        m_pages->setCurrentWidget(m_menuPage);
    });
    connect(menu, &QPushButton::clicked, this, [this] {
        m_pages->setCurrentWidget(m_menuPage);
    });
    connect(newGame, &QPushButton::clicked, this, &MainWindow::startGame);

    m_pages->addWidget(m_gamePage);
}

void MainWindow::buildResultPage()
{
    m_resultPage = new QWidget;
    auto *layout = new QVBoxLayout(m_resultPage);
    layout->setContentsMargins(80, 70, 80, 70);
    layout->addStretch();

    m_resultTitle = new QLabel;
    m_resultTitle->setObjectName("resultTitle");
    m_resultTitle->setAlignment(Qt::AlignCenter);

    m_resultWord = new QLabel;
    m_resultWord->setObjectName("word");
    m_resultWord->setAlignment(Qt::AlignCenter);

    auto *again = makeButton("Play again", "primaryButton");
    auto *menu = makeButton("Main menu");

    layout->addWidget(m_resultTitle);
    layout->addWidget(m_resultWord);
    layout->addSpacing(25);
    layout->addWidget(again);
    layout->addWidget(menu);
    layout->addStretch();

    connect(again, &QPushButton::clicked, this, &MainWindow::startGame);
    connect(menu, &QPushButton::clicked, this, [this] {
        m_pages->setCurrentWidget(m_menuPage);
    });

    m_pages->addWidget(m_resultPage);
}

void MainWindow::applyStyle()
{
    setStyleSheet(R"(
        QMainWindow, QWidget {
            background: #f5f7fa;
            color: #1e293b;
            font-family: "Segoe UI";
            font-size: 14px;
        }
        QLabel#mainTitle {
            font-size: 42px;
            font-weight: 700;
            letter-spacing: 5px;
            color: #172554;
        }
        QLabel#subtitle { color: #64748b; font-size: 16px; }
        QLabel#sectionTitle { font-size: 23px; font-weight: 700; color: #172554; }
        QLabel#attempts { font-size: 16px; font-weight: 600; color: #475569; }
        QLabel#word { font-size: 30px; font-weight: 700; letter-spacing: 7px; color: #0f172a; }
        QLabel#feedback { font-size: 15px; color: #2563eb; min-height: 24px; }
        QLabel#resultTitle { font-size: 34px; font-weight: 700; color: #172554; }
        QPushButton {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 9px 16px;
            color: #334155;
            font-weight: 600;
        }
        QPushButton:hover { background: #eaf0f8; border-color: #94a3b8; }
        QPushButton:disabled { color: #94a3b8; background: #e2e8f0; }
        QPushButton#primaryButton {
            background: #2563eb;
            color: white;
            border: none;
            font-size: 16px;
            min-height: 48px;
        }
        QPushButton#primaryButton:hover { background: #1d4ed8; }
        QPushButton#letterButton { padding: 4px; font-size: 15px; }
        QComboBox {
            background: white;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding: 9px 12px;
        }
    )");
}

void MainWindow::startGame()
{
    const int length = m_lengthBox->currentData().toInt();
    if (!m_game.startNewGame(length)) {
        QMessageBox::warning(this, "No words", "There are no words with that length.");
        return;
    }

    // Reset all on-screen letter buttons for the new round.
    const auto buttons = m_gamePage->findChildren<QPushButton *>("letterButton");
    for (QPushButton *button : buttons)
        button->setEnabled(true);

    m_feedbackLabel->setText("Choose a letter");
    updateGameScreen();
    m_pages->setCurrentWidget(m_gamePage);
}

void MainWindow::updateGameScreen()
{
    m_figure->setWrongCount(m_game.wrongCount());
    m_wordLabel->setText(m_game.maskedWord());
    m_guessedLabel->setText("Guessed letters: " +
        (m_game.guessedLetters().isEmpty() ? QString("—") : m_game.guessedLetters()));
    m_attemptsLabel->setText(QString("Incorrect guesses remaining: %1 / %2")
        .arg(m_game.guessesLeft()).arg(m_game.maxWrong()));
}

void MainWindow::handleLetter(const QString &letter)
{
    const auto result = m_game.makeGuess(letter.at(0));

    switch (result) {
    case HangmanGame::GuessResult::Correct:
        m_feedbackLabel->setText("Correct guess!");
        break;
    case HangmanGame::GuessResult::Wrong:
        m_feedbackLabel->setText("That letter is not in the word.");
        break;
    case HangmanGame::GuessResult::AlreadyGuessed:
        m_feedbackLabel->setText("You already guessed that letter.");
        break;
    case HangmanGame::GuessResult::Invalid:
        m_feedbackLabel->setText("Please choose a letter from A to Z.");
        break;
    }

    // Disable the selected key, including duplicate protection in the game logic.
    const auto buttons = m_gamePage->findChildren<QPushButton *>("letterButton");
    for (QPushButton *button : buttons) {
        if (button->text() == letter)
            button->setEnabled(false);
    }

    updateGameScreen();
    if (m_game.isFinished())
        showResult();
}

void MainWindow::showResult()
{
    if (m_game.isWon()) {
        m_resultTitle->setText("You won!");
        m_resultTitle->setStyleSheet("color: #15803d;");
    } else {
        m_resultTitle->setText("Game over");
        m_resultTitle->setStyleSheet("color: #b91c1c;");
    }
    m_resultWord->setText("The word was: " + m_game.secretWord());
    m_pages->setCurrentWidget(m_resultPage);
}
