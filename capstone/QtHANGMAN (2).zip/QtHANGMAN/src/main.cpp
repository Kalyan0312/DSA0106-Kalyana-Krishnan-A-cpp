#include "MainWindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QApplication::setApplicationName("Hangman");
    QApplication::setOrganizationName("HangmanProject");

    MainWindow window;
    window.show();

    return app.exec();
}
