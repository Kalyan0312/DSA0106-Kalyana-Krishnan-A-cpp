#pragma once

#include <QString>
#include <QSet>
#include <QStringList>

class HangmanGame
{
public:
    enum class GuessResult { Correct, Wrong, AlreadyGuessed, Invalid };

    HangmanGame();

    bool startNewGame(int wordLength);
    GuessResult makeGuess(QChar letter);

    QString maskedWord() const;
    QString guessedLetters() const;
    QString secretWord() const;

    int wrongCount() const { return m_wrongCount; }
    int maxWrong() const { return 6; }
    int guessesLeft() const { return maxWrong() - m_wrongCount; }
    bool isWon() const;
    bool isLost() const;
    bool isFinished() const { return isWon() || isLost(); }

private:
    QString m_word;
    QSet<QChar> m_guessed;
    int m_wrongCount = 0;

    static const QStringList s_words;
};
