#include "HangmanGame.h"
#include <QRandomGenerator>

const QStringList HangmanGame::s_words = {
    "CAT", "DOG", "SUN", "MAP", "PEN",
    "GAME", "CODE", "TREE", "FISH", "MOON", "BOOK", "RAIN",
    "APPLE", "HOUSE", "PLANT", "RIVER", "CLOUD", "TIGER", "BREAD",
    "PYTHON", "ORANGE", "BRIDGE", "SCHOOL", "GARDEN", "PLANET",
    "COMPUTER", "ELEPHANT", "MOUNTAIN", "KEYBOARD", "SANDWICH",
    "ADVENTURE", "CHOCOLATE", "UNIVERSITY", "PROGRAMMER"
};

HangmanGame::HangmanGame() = default;

bool HangmanGame::startNewGame(int wordLength)
{
    QStringList candidates;
    for (const QString &word : s_words) {
        if (word.size() == wordLength)
            candidates.append(word);
    }

    if (candidates.isEmpty())
        return false;

    const int index = QRandomGenerator::global()->bounded(candidates.size());
    m_word = candidates.at(index);
    m_guessed.clear();
    m_wrongCount = 0;
    return true;
}

HangmanGame::GuessResult HangmanGame::makeGuess(QChar letter)
{
    letter = letter.toUpper();

    if (letter < QLatin1Char('A') || letter > QLatin1Char('Z'))
        return GuessResult::Invalid;

    if (m_guessed.contains(letter))
        return GuessResult::AlreadyGuessed;

    m_guessed.insert(letter);

    if (m_word.contains(letter))
        return GuessResult::Correct;

    ++m_wrongCount;
    return GuessResult::Wrong;
}

QString HangmanGame::maskedWord() const
{
    QString result;
    for (QChar letter : m_word) {
        result += m_guessed.contains(letter) ? letter : QLatin1Char('_');
        result += QLatin1Char(' ');
    }
    return result.trimmed();
}

QString HangmanGame::guessedLetters() const
{
    QStringList letters;
    for (QChar letter : m_guessed)
        letters.append(QString(letter));
    letters.sort();
    return letters.join("  ");
}

QString HangmanGame::secretWord() const
{
    return m_word;
}

bool HangmanGame::isWon() const
{
    if (m_word.isEmpty())
        return false;

    for (QChar letter : m_word) {
        if (!m_guessed.contains(letter))
            return false;
    }
    return true;
}

bool HangmanGame::isLost() const
{
    return m_wrongCount >= maxWrong();
}
