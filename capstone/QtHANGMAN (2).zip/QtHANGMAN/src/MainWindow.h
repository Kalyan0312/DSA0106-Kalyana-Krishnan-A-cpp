#pragma once

#include <QMainWindow>
#include "HangmanGame.h"

class QStackedWidget;
class QLabel;
class QPushButton;
class QComboBox;
class HangmanWidget;
class QWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    QStackedWidget *m_pages = nullptr;
    HangmanGame m_game;

    QWidget *m_menuPage = nullptr;
    QWidget *m_gamePage = nullptr;
    QWidget *m_resultPage = nullptr;

    QComboBox *m_lengthBox = nullptr;
    HangmanWidget *m_figure = nullptr;
    QLabel *m_wordLabel = nullptr;
    QLabel *m_guessedLabel = nullptr;
    QLabel *m_attemptsLabel = nullptr;
    QLabel *m_feedbackLabel = nullptr;
    QLabel *m_resultTitle = nullptr;
    QLabel *m_resultWord = nullptr;

    void buildMenuPage();
    void buildGamePage();
    void buildResultPage();
    void applyStyle();
    void startGame();
    void updateGameScreen();
    void handleLetter(const QString &letter);
    void showResult();
    QPushButton *makeButton(const QString &text, const QString &objectName = {});
};
