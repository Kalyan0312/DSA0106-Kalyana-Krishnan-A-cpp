#include "HangmanWidget.h"
#include <QPainter>
#include <QPen>

HangmanWidget::HangmanWidget(QWidget *parent) : QWidget(parent)
{
    setMinimumSize(220, 250);
    setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}

void HangmanWidget::setWrongCount(int count)
{
    m_wrongCount = qBound(0, count, 6);
    update();
}

void HangmanWidget::paintEvent(QPaintEvent *)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing);

    const QColor ink("#334155");
    QPen pen(ink, 5, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    p.setPen(pen);

    const qreal w = width();
    const qreal h = height();
    const qreal baseY = h - 24;
    const qreal poleX = w * 0.28;
    const qreal topY = 28;

    // Gallows
    p.drawLine(QPointF(w * 0.10, baseY), QPointF(w * 0.62, baseY));
    p.drawLine(QPointF(poleX, baseY), QPointF(poleX, topY));
    p.drawLine(QPointF(poleX, topY), QPointF(w * 0.70, topY));
    p.drawLine(QPointF(w * 0.70, topY), QPointF(w * 0.70, h * 0.20));

    QPen figurePen(QColor("#64748b"), 4, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin);
    p.setPen(figurePen);

    const qreal headY = h * 0.31;
    const qreal bodyTop = h * 0.39;
    const qreal bodyBottom = h * 0.66;
    const qreal centerX = w * 0.70;

    if (m_wrongCount >= 1)
        p.drawEllipse(QPointF(centerX, headY), 21, 21);
    if (m_wrongCount >= 2)
        p.drawLine(QPointF(centerX, headY + 21), QPointF(centerX, bodyBottom));
    if (m_wrongCount >= 3)
        p.drawLine(QPointF(centerX, bodyTop + 8), QPointF(centerX - 30, bodyTop + 42));
    if (m_wrongCount >= 4)
        p.drawLine(QPointF(centerX, bodyTop + 8), QPointF(centerX + 30, bodyTop + 42));
    if (m_wrongCount >= 5)
        p.drawLine(QPointF(centerX, bodyBottom), QPointF(centerX - 28, h * 0.83));
    if (m_wrongCount >= 6)
        p.drawLine(QPointF(centerX, bodyBottom), QPointF(centerX + 28, h * 0.83));
}
