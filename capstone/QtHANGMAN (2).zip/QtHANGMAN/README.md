# Hangman — Qt Widgets (C++)

A Windows desktop Hangman game built entirely in C++ using Qt 6 Widgets.
The interface uses Qt Widgets and QPainter; there is no HTML, CSS, JavaScript,
Python, or web view in the application.

## Project structure

```text
HangmanQt/
├── CMakeLists.txt
├── README.md
└── src/
    ├── main.cpp
    ├── HangmanGame.h
    ├── HangmanGame.cpp
    ├── HangmanWidget.h
    ├── HangmanWidget.cpp
    ├── MainWindow.h
    └── MainWindow.cpp
```

## Requirements

- Qt 6 (Widgets component)
- CMake 3.16 or newer
- A C++17 compiler (Visual Studio 2022 is recommended on Windows)

## Build using Qt Creator

1. Install Qt 6 with the **Qt Widgets** component and a matching compiler kit.
2. Open `CMakeLists.txt` in Qt Creator.
3. Select a desktop kit (for example, Qt 6 + MinGW 64-bit or MSVC 2022).
4. Configure the project, then click **Build** and **Run**.

## Build using the command line

Open a terminal in this project folder. Make sure CMake and the selected Qt kit
are on PATH, or set `CMAKE_PREFIX_PATH` to your Qt installation.

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/mingw_64"
cmake --build build --config Release
```

The executable will be placed in the build output directory. The exact path
depends on the generator and Qt kit.

## Current features

- Minimal clean main menu
- Word-length selection (3–10 letters)
- Random word selection from the original word list
- Clickable A–Z keyboard
- Graphically drawn hangman
- Guessed-letter and remaining-attempt counters
- Win/loss result page
- Play again and return-to-menu controls

## Notes

The original word list and six-wrong-guess rule have been preserved.
The console input/output has been replaced with Qt widgets and signals/slots.
